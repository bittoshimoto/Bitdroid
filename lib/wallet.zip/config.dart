class Config {
  static const String addressPrefix = 'bit';
  static const int networkPrefix = 0x88;

  static const String rpcUrl = 'http://45.14.50.31:9876';
  static const String rpcUser = 'rpc_bittoshi';
  static const String rpcPassword = 'dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeyt53';

  static const String explorerUrl =
      'https://bit-explorer.pool.sexy';
  static const String getAddressTxsEndpoint = '/ext/getaddresstxs';
  static const String getTxEndpoint = '/ext/gettx';

  static const String priceUrl = 'https://api.xeggex.com/api/v2/asset/getbyticker/B1T';
}
